
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "disco.h"

typedef struct Usuario {
	char usrName[32];
	char password[32];
	int edad;
	int numCompras;
	char **discosComprados;
	struct Usuario* sig;
}Usuario;

Usuario* inicioListaUsuarios = NULL;
Usuario* finalListaUsuarios = NULL;
int numUsuarios = 0;

Usuario* crearUsuario(char usrName[], char password[], int edad, int numCompras, char **discosComprados);
enum boolean listaUsuariosVacia();
void agregarUsuario(Usuario* usuario);
Usuario* borrarUsuario(char usrName[]);

enum boolean nombreUsuarioRegistrado(char usrName[]);
void registrarUsuario();
void modificarUsuario(char usrName[]);
void comprarDisco(char usrName[], char discName[]);
void mostrarUsuarios();
void mostrarUsuario(char usrName[]);
void cargarListaUsuarios();
void leerArchivoUsuario(char nomArch[]);
void guardarListaUsuarios();
void escribirArchivoUsuario(char nomArch[],Usuario* usuario);
void eliminarArchivoUsuario(Usuario* usuario);

Usuario* crearUsuario(char usrName[], char password[], int edad, int numCompras, char **discosComprados) {
	int i;

	Usuario* nuevo = (Usuario*)malloc(sizeof(Usuario));
	strcpy(nuevo->usrName,usrName);
	strcpy(nuevo->password,password);
	nuevo->edad = edad;
	nuevo->numCompras = numCompras;
	nuevo->discosComprados = discosComprados;
	nuevo->sig = NULL;
	return nuevo;
}

enum boolean listaUsuariosVacia() {
	if(inicioListaUsuarios == NULL && finalListaUsuarios == NULL) return true;
	else return false;
}

void agregarUsuario(Usuario* usuario) {
	if (inicioListaUsuarios == NULL){
		inicioListaUsuarios = usuario;
	}else {
		finalListaUsuarios->sig = usuario;
	}
	finalListaUsuarios = usuario;
	numUsuarios++;
}

void modificarUsuario(char usrName[]) {
	if(listaUsuariosVacia()) {
		printf("No hay usuarios.\n");
	}else {
		int opcion;
		char buffer[8]={'\0'};
		Usuario* scout = inicioListaUsuarios;
		while( strcmp(scout->usrName,usrName) != 0 ) {
			scout = scout->sig;
			if (scout == NULL) {
				printf("Usuario \"%s\" no encontrado.\n",usrName);
				return;
			}
		}
		printf("Ingrese sus nuevos datos.\n");
		printf("Contraseña: ");
		scanf(" %[^\n]",scout->password);
		do {
			printf("Edad: ");
			scanf("%s",buffer);
		} while (!validarEntero(buffer));
		scout->edad = atoi(buffer);
	}
}

Usuario* borrarUsuario(char usrName[]) {
	if(listaUsuariosVacia()) {
		return (Usuario*)NULL;
	}
	Usuario* aux = inicioListaUsuarios;
	if (inicioListaUsuarios == finalListaUsuarios && strcmp(aux->usrName,usrName) == 0) {
		inicioListaUsuarios = NULL;
		finalListaUsuarios = NULL;
		eliminarArchivoUsuario(aux);
		numUsuarios--;
		return aux;
	}else if (strcmp(aux->usrName,usrName) == 0) {
		printf("Entre aqui\n");
		inicioListaUsuarios = inicioListaUsuarios->sig;
		aux->sig = NULL;
		eliminarArchivoUsuario(aux);
		numUsuarios--;
		return aux;
	}else {
		printf("Entre aca\n");
		Usuario* scout = inicioListaUsuarios;
		while(strcmp(scout->usrName,usrName) != 0) {
			scout = scout->sig;
			if(scout == NULL) {
				return NULL;
			}
		}
		
		while(aux->sig != scout) {
			aux = aux->sig;
		}

		aux->sig = scout->sig;
		scout->sig = NULL;
		eliminarArchivoUsuario(scout);
		numUsuarios--;
		return scout;
	}
}

enum boolean nombreUsuarioRegistrado(char usrName[]) {
	Usuario* aux = inicioListaUsuarios;
	while(aux != NULL && strcmp(aux->usrName,usrName) != 0) {
		aux = aux->sig;
	}
	if (aux != NULL && strcmp(aux->usrName,usrName) == 0) {
		return true;
	}
	else {
		return false;
	}
}

void registrarUsuario() {
	char usrName[32];
	char password[32];
	int edad;
	char buffer[32] = {'\0'};
	do {
		if(nombreUsuarioRegistrado(usrName)){
			printf("Nombre de usuario ya registrado.\n");
		}
		printf("Ingrese nombre de usuario: ");
		scanf(" %[^\n]",usrName);
	} while (nombreUsuarioRegistrado(usrName));
	printf("Ingrese password de usuario: ");
	scanf(" %[^\n]",password);
	do {
		printf("Edad: ");
		scanf("%s",buffer);
	} while (!validarEntero(buffer));
	edad = atoi(buffer);
	agregarUsuario(crearUsuario(usrName,password,edad,0,NULL));
	printf("Usuario agregado.\n");
}

void comprarDisco(char usrName[], char discName[]) {
	Usuario* usuario = inicioListaUsuarios;
	Disco* disco = inicioListaDiscos;
	if(listaUsuariosVacia() || listaDiscosVacia()) {
		printf("No hay usuarios.\n");
	}
	else if (discoEnLista(discName)) {
		while(usuario != NULL && strcmp(usuario->usrName,usrName) != 0) {
			usuario = usuario->sig;
		}
		while(disco != NULL && strcmp(disco->discName,discName) != 0) {
			disco = disco->sig;
		}
		if (usuario != NULL && disco != NULL) {
			printf("Copiando %s a discos comprados por %s",disco->discName,usuario->usrName);
			strcpy(usuario->discosComprados[usuario->numCompras],disco->discName);
			printf("Copiado\n");
			usuario->numCompras++;
			disco->numCompras++;
			printf("Compra de \"%s\" realizada.\n",disco->discName);
		}
	}
	else {
		printf("Disco \"%s\" no encontrado.\n",discName);
	}
}

void mostrarUsuarios() {
	//Si la lista está vacía.
	if(listaUsuariosVacia()) {
		printf("No hay usuarios.\n");
	}
	else {
		Usuario* aux = inicioListaUsuarios;
		printf("\n\tLista de usuarios:\n");
		while(aux != NULL) {
			printf("- %s\n", aux->usrName);
			aux = aux->sig;
		}	
	}
}

void mostrarUsuario(char usrName[]) {
	if(listaUsuariosVacia()) {
		printf("No hay usuarios.\n");
	}
	else {
		Usuario* aux = inicioListaUsuarios;
		while(aux != NULL && strcmp(aux->usrName,usrName) != 0 ) {
			aux = aux->sig;
		}
		printf("\nNombre de usuario: %s \n",aux->usrName);
		printf("Edad: %d \n",aux->edad);
		printf("Compras realizadas:\n");
		int i;
		for(i = 0; i < aux->numCompras; i++) {
			printf("- %s\n",aux->discosComprados[i]);
		}
		printf("\n");
	}
}

void cargarListaUsuarios() {
	DIR* directorio;
	struct dirent *ent;
	char nomCarpeta[40] =  "./usuarios/";
	directorio = opendir("./usuarios/");
	if (directorio == NULL) {
		printf("Error al cargar directorio.\n");
	}
	else {
		while ((ent = readdir(directorio)) !=  NULL) {
			strcpy(nomCarpeta,"./usuarios/");
			if ((strcmp(ent->d_name, ".") != 0) && (strcmp(ent->d_name, "..") != 0)) {
				strcat(nomCarpeta,ent->d_name);
				leerArchivoUsuario(nomCarpeta);
			}
		}
		closedir(directorio);
	}
}

void leerArchivoUsuario(char nomArch[]) {
	FILE* usrArch = fopen(nomArch,"r");
	if (usrArch == NULL) {
		printf("Error al cargar. Verifique el archivo.\n");

	}
	else {
		char usrName[32];
		char password[32];
		int edad;
		int numCompras;
		int i;
		char test[32]={'\0'};
		char **discosComprados = (char**)calloc(32,sizeof(char*));
		for (i = 0; i<32; i++) {
			discosComprados[i] = (char*)calloc(32,sizeof(char));
		}
		fscanf(usrArch," %[^\n]\n",usrName);
		fscanf(usrArch," %[^\n]\n",password);
		fscanf(usrArch,"%d\n",&edad);
		fscanf(usrArch,"%d\n",&numCompras);
		for(i = 0; i< numCompras; i++) {
			fscanf(usrArch," %[^\n]\n",discosComprados[i]);
		}
		agregarUsuario(crearUsuario(usrName,password,edad,numCompras,discosComprados));
		fclose(usrArch);
	}
}

void guardarListaUsuarios() {
	char nomCarpeta[40];
	Usuario* aux = inicioListaUsuarios;
	while (aux != NULL) {
		strcpy(nomCarpeta,"./usuarios/");
		strcat(nomCarpeta,aux->usrName);
		strcat(nomCarpeta,".txt");
		escribirArchivoUsuario(nomCarpeta,aux);
		aux = aux->sig;
	}
}

void escribirArchivoUsuario(char nomArch[],Usuario* usuario) {
	int i;
	FILE* usrArch = fopen(nomArch,"w");
	if (usrArch == NULL) {
		printf("Error al guardar el inventario. Verifique el archivo.\n");
		return;
	}
	else {
		fprintf(usrArch,"%s\n",usuario->usrName);
		fprintf(usrArch,"%s\n",usuario->password);
		fprintf(usrArch,"%d\n",usuario->edad);
		fprintf(usrArch,"%d\n",usuario->numCompras);
		for(i = 0; i< usuario->numCompras; i++) {
			fprintf(usrArch,"%s\n",usuario->discosComprados[i]);
		}
		fclose(usrArch);
	}
}

void eliminarArchivoUsuario(Usuario* usuario) {
	printf("Archivo de: %s.\n",usuario->usrName);
	char nomArch[40] =  "./usuarios/";
	strcat(nomArch,usuario->usrName);
	strcat(nomArch,".txt");
}