/*
	- Limpiador de pantalla (clear screen)
	- Validaciones de tipo
	- Conversión de tipo
	- Formato de impresión
	- pause
*/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

enum boolean{false, true};

enum boolean validarEntero(char buffer[]);
enum boolean validarFlotante(char buffer[]);
char* enteroACadena(int numero);
char* flotanteACadena(float numero);
void imprimirDatoCadena(char cadena[]);
void imprimirDatoEntero(int numero);
void imprimirDatoFlotante(float numero);

void pause();

enum boolean validarEntero(char buffer[]) {
	int i = 0;
	
	while (i < strlen(buffer)) {
		if (!isdigit(buffer[i])) {
			printf("Dato inválido...\n");
			return false;
		}
		i++;
	}
	return true;
}

enum boolean validarFlotante(char buffer[]) {
	int i = 0;

	if (buffer[i] == '.' && strlen(buffer) == 1) {
		printf("Dato inválido...\n");
		return false;
	}
	while (i < strlen(buffer)) {
		if (!isdigit(buffer[i]) && buffer[i] != '.') {
			printf("Dato inválido...\n");
			return false;
		}
		i++;
	}
	return true;
}

char* enteroACadena(int numero){
	char* cadena = (char*)calloc(10,sizeof(char));
	sprintf(cadena,"%i",numero);
	return cadena;
}

char* flotanteACadena(float numero){
	char* cadena = (char*)calloc(10,sizeof(char));
	sprintf(cadena,"%.2f",numero);
	return cadena;
}

void imprimirDatoCadena(char cadena[]) {
	int tamanio = 32;
	int numEsp = tamanio - strlen(cadena);
	int i;

	printf("%s",cadena);
	for(i = 0; i < numEsp-1; i++) {
		printf(" ");
	}
}

void imprimirDatoEntero(int numero) {
	int tamanio = 10;
	char* cadena = enteroACadena(numero);
	int numEsp = tamanio - strlen(cadena);
	int i;

	for(i = 0; i < numEsp-1; i++) {
		printf(" ");
	}
	printf("%s",cadena);
}

void imprimirDatoFlotante(float numero) {
	int tamanio = 10;
	char* cadena = flotanteACadena(numero);
	int numEsp = tamanio - strlen(cadena);
	int i;

	for(i = 0; i < numEsp-1; i++) {
		printf(" ");
	}
	printf("%s",cadena);
}

void pause() {
	printf("Presione Enter para continuar...");
	getchar();
	getchar();
}
