/*
	Programa que implementa un sistema electrónico de una tienda de música.
	Erick Misael López Vite
*/

#include <stdio.h>
#include "usuario.h"

Usuario* validaUsuario();
void menuAdmin();
void menuUsuario();
void menuOrdenar();
void menuBusqueda();

int main(int argc, char const *argv[]) {
	cargarListaUsuarios();
	cargarInventario();
	int opcion;

	do {
		system("clear");
		printf("\tBienvenido a la tienda n.n/\n");
		printf("\nMenú principal\n");
		printf("\n1. Iniciar sesión\n");
		printf("2. Salir\n\n");
		printf("Ingrese una opción: ");
		scanf("%d",&opcion);
		getchar();

		switch(opcion){
			case 1:	{
				Usuario* usuarioActual = validaUsuario();
				if (usuarioActual == NULL) {
				}else if (strcmp(usuarioActual->usrName,"admin") == 0) {
					menuAdmin();
				}else {
					menuUsuario(usuarioActual);
				}
			}
			break;
			case 2:
				printf("\nHasta Luego n.n/\n");
			break;
			default:
				printf("Opción inválida.\n");
				pause();
		}

	}while(opcion!=2);

	return 0;
}


Usuario* validaUsuario(){

	int intentos = 3;

	char usuarioIngresado[16]={'\0'}, passwordIngresada[16]={'\0'};

	//ClearScreen();
	system("clear");
	printf("\nInicio de sesión\n\n");
	do {
		printf("Usuario: ");
		scanf(" %[^\n]",usuarioIngresado);
		printf("Contraseña: ");
		scanf(" %[^\n]",passwordIngresada);
		if(listaUsuariosVacia()) {
			printf("No existen usuarios\n");
		}
		else {
			Usuario* aux = inicioListaUsuarios;
			while(aux != NULL && strcmp(aux->usrName,usuarioIngresado) != 0) {
				aux = aux->sig;
			}
			if (aux != NULL && strcmp(aux->password,passwordIngresada) == 0) {
				return aux;
			}
		}
		printf("\nError, usuario o contraseña incorrectos\n\n");
		intentos--;
	} while(intentos > 0);
	if (intentos == 0) printf("Regresando al menu principal...\n");
	pause();
	return NULL;
}

void menuAdmin(){
	char artista[32];
	char discName[32];
	float precio;
	int anio;
	char usrName[32];
	char password[32];
	int edad;
	char buffer[32] = {'\0'};
	int opcion;

	do{
		system("clear");
		printf("\nBienvenido, admin\n");
		printf("\nMenú del administrador\n\n");
		printf("1. Mostrar todos los discos\n");
		printf("2. Agregar un disco\n");
		printf("3. Remover un disco\n");
		printf("4. Modificar los datos de un disco\n");
		printf("5. Buscar discos\n");
		printf("6. Ordenar los discos\n");
		printf("7. Ver lista de usuarios\n");
		printf("8. Agregar usuario\n");
		printf("9. Remover usuario\n");
		printf("0. Salir\n\n");
		printf("Ingrese una opción: ");
		scanf("%d",&opcion);
		
		switch(opcion) {
			case 1:
				mostrarDiscos();
				pause();
				break;
			case 2:
				registrarDisco();
				pause();
				break;
			case 3:
				printf("Ingrese nombre del disco: ");
				scanf(" %[^\n]",discName);
				if (discoEnLista(discName)) {
					printf("\"%s\" ha sido removido.\n",borrarDisco(discName)->discName);
				}
				else {
					printf("Disco \"%s\" no encontrado.\n",discName);
				}
				pause();
				break;
			case 4:
				printf("Ingrese nombre del disco: ");
				scanf(" %[^\n]",discName);
				modificarDisco(discName);
				pause();
				break;
			case 5:
				menuBusqueda();
				pause();
				break;
			case 6:
				menuOrdenar();
				pause();
				break;
			case 7:
				mostrarUsuarios();
				pause();
				break;
			case 8:
				registrarUsuario();
				guardarListaUsuarios();
				pause();
				break;
			case 9:
				printf("Ingrese nombre de usuario: ");
				scanf(" %[^\n]",usrName);
				if(nombreUsuarioRegistrado(usrName)) {
					printf("\"%s\" ha sido removido.\n",borrarUsuario(usrName)->usrName);
				}
				else {
					printf("Usuario \"%s\" no encontrado.\n",usrName);
				}
				guardarListaUsuarios();
				pause();
				break;
			case 0:
				printf("\nHasta luego, admin n.n/ \n\n");
				pause();
				break;
			default:
				printf("\nOpción inválida.\n");
				pause();
		}
		guardarDiscos();
	} while (opcion!=0);
}

void menuOrdenar() {
	int opcion;
	char buffer[32] = {'\0'};

	printf("\nMenú de ordenamiento.\n\n");
	printf("1. Por nombre.\n");
	printf("2. Por artista.\n");
	printf("3. Por precio.\n");
	printf("4. Por año.\n");
	printf("5. Por número de compras.\n");
	printf("6. Cancelar.\n\n");
	do {
		printf("Ingrese una opción: ");
		scanf(" %[^\n]",buffer);
	} while (!validarEntero(buffer));
	opcion = atoi(buffer);

	switch(opcion) {
		case 1:
			ordenarDiscosNombre();
		break;
		case 2:
			ordenarDiscosArtista();
		break;
		case 3:
			ordenarDiscosPrecio();
		break;
		case 4:
			ordenarDiscosAnio();
		break;
		case 5:
			ordenarDiscosNumCompras();
		break;
	}
}

void menuBusqueda(){
	int opcion;
	char buffer[32] = {'\0'};
	float precio;
	int anio;

	printf("\nMenú de búsqueda.\n\n");
	printf("1. Por nombre.\n");
	printf("2. Por artista.\n");
	printf("3. Por precio.\n");
	printf("4. Por año.\n");
	printf("Otro. Cancelar.\n\n");
	do {
		printf("Ingrese una opción: ");
		scanf(" %[^\n]",buffer);
	} while (!validarEntero(buffer));
	opcion = atoi(buffer);

	switch(opcion) {
		case 1:
			printf("Ingrese el nombre del disco: ");
			scanf(" %[^\n]",buffer);
			buscarDiscoNombre(buffer);
		break;
		case 2:
			printf("Ingrese el artista del disco: ");
			scanf(" %[^\n]",buffer);
			buscarDiscoArtista(buffer);
		break;
		case 3:
			do {
				printf("Ingrese el precio: ");
				scanf(" %[^\n]",buffer);
			} while (!validarFlotante(buffer));
			precio = atof(buffer);

			printf("\nSubmenú: (1) Precio menor a | (2) Precio mayor a | (3) Precio igual a\n");
			enum boolean f_busqueda = true;
			do {
				do {
					printf("Ingrese una opción: ");
					scanf(" %[^\n]",buffer);
				} while (!validarEntero(buffer));
				opcion = atoi(buffer);

				switch(opcion) {
					case 1:
						buscarDiscoPrecioMenor(precio);
					break;
					case 2:
						buscarDiscoPrecioMayor(precio);
					break;
					case 3:
						buscarDiscoPrecioIgual(precio);
					break;
					default:
						printf("Opción invalida.\n");
						f_busqueda = false;
				}
			} while (f_busqueda == false);
		break;
		case 4:
			do {
			printf("Ingrese el año: ");
				scanf(" %[^\n]",buffer);
			} while (!validarEntero(buffer));
			anio = atoi(buffer);
			buscarDiscoAnio(anio);
		break;
	}
}

void menuUsuario(Usuario* usuarioActual){
	char artista[32];
	char discName[32];
	float precio;
	int anio;
	char usrName[32];
	char password[32];
	int edad;
	char buffer[32] = {'\0'};
	int opcion;

	do { 
		system("clear");
		printf("\nBienvenido, %s\n\n\n",usuarioActual->usrName);
		printf("Menú del usuario\n\n");
		printf("1. Mostrar todos los discos\n");
		printf("2. Buscar discos\n");
		printf("3. Comprar un disco\n");
		printf("4. Ver perfil\n");
		printf("5. Editar perfil\n");
		printf("6. Salir\n\n");
		printf("Ingrese una opción: ");
		scanf("%d",&opcion);
		

		switch(opcion) {
			case 1:
				mostrarDiscos();
				pause();
				break;
			case 2:
				menuBusqueda();
				pause();
				break;
			case 3:
				printf("Ingrese el nombre del disco que desea comprar: ");
				scanf(" %[^\n]",buffer);
				comprarDisco(usuarioActual->usrName,buffer);
				pause();
				break;
			case 4:
				mostrarUsuario(usuarioActual->usrName);
				pause();
				break;
			case 5:
				modificarUsuario(usuarioActual->usrName);
				guardarListaUsuarios();
				pause();
				break;
			case 6:
				printf("\nHasta luego, %s n.n/ \n\n",usuarioActual->usrName);
				pause();
				break;
			default:
				printf("\nOpción inválida.\n");
				pause();
		}
		guardarListaUsuarios();
		guardarDiscos();
	} while (opcion!=6);
}