#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/types.h>
#include <dirent.h>
#include "extras.h"

typedef struct Disco {
	char discName[24];
	char artista[24];
	float precio;
	int anio;
	int numCompras;
	struct Disco* sig;
}Disco;

Disco* inicioListaDiscos = NULL;
Disco* finalListaDiscos = NULL;
int numDiscos = 0;

Disco* crearDisco(char discName[], char artista[], float precio, int anio, int numCompras);
enum boolean listaDiscosVacia();
void agregarDisco(Disco* disco);
Disco* borrarDisco(char discName[]);

enum boolean discoEnLista(char discName[]);
void registrarDisco();
void modificarDisco(char discName[]);
void mostrarDiscos();
void imprimirDisco(Disco* disco);
void ordenarDiscosNombre();
void ordenarDiscosArtista();
void ordenarDiscosPrecio();
void ordenarDiscosAnio();
void ordenarDiscosNumCompras();
void buscarDiscoNombre(char discName[]);
void buscarDiscoArtista(char artista[]);
void buscarDiscoAnio(int anio);
void buscarDiscoPrecioMenor(float precio);
void buscarDiscoPrecioMayor(float precio);
void buscarDiscoPrecioIgual(float precio);
void cargarInventario();
void leerArchivoDisco(char nomArch[]);
void guardarDiscos();
void escribirArchivoDisco(char nomArch[],Disco* disco);
void eliminarArchivoDisco(Disco* disco);
void renombrarArchivoDisco(char oldName[],char newName[]);

Disco* crearDisco(char discName[], char artista[], float precio, int anio, int numCompras) {
	Disco* nuevo = (Disco*)malloc(sizeof(Disco));
	strcpy(nuevo->discName,discName);
	strcpy(nuevo->artista,artista);
	nuevo->precio = precio;
	nuevo->anio = anio;
	nuevo->numCompras = numCompras;
	nuevo->sig = NULL;
	return nuevo;
}

enum boolean listaDiscosVacia() {
	if(inicioListaDiscos == NULL && finalListaDiscos == NULL) return true;
	else return false;
}

void agregarDisco(Disco* disco) {
	if(listaDiscosVacia()) {
		inicioListaDiscos = disco;
	}
	else {
		finalListaDiscos->sig = disco;
	}
	finalListaDiscos = disco;
	numDiscos++;
}

enum boolean discoEnLista(char discName[]) {
	Disco* aux = inicioListaDiscos;
	while(aux != NULL && strcmp(aux->discName,discName) != 0) {
		aux = aux->sig;
	}
	if (aux != NULL && strcmp(aux->discName,discName) == 0) {
		return true;
	}
	else {
		return false;
	}
}

void registrarDisco() {
	char discName[24];
	printf("Ingrese nombre del disco: ");
	scanf(" %[^\n]",discName);
	if (discoEnLista(discName)) {
		printf("\"%s\" ya existe en la lista\n", discName);
		return;
	}
	char artista[24];
	float precio;
	int anio;
	char buffer[24];
	printf("Ingrese artista: ");
	scanf(" %[^\n]",artista);
	do {
		printf("Precio: ");
		scanf("%s",buffer);
	} while (!validarFlotante(buffer));
	precio = atof(buffer);
	do {
		printf("Año de lanzamiento: ");
		scanf("%s",buffer);
	} while (!validarEntero(buffer));
	anio = atoi(buffer);
	agregarDisco(crearDisco(discName,artista,precio,anio,0));
	printf("Disco agregado.\n");
}

Disco* borrarDisco(char discName[]) {
	if(listaDiscosVacia()) {
		return (Disco*)NULL;
	}
	Disco* aux = inicioListaDiscos;
	if (inicioListaDiscos == finalListaDiscos && strcmp(aux->discName,discName) == 0 ) {
		inicioListaDiscos = NULL;
		finalListaDiscos = NULL;
		eliminarArchivoDisco(aux);
		numDiscos--;
		return aux;
	}
	else if (strcmp(aux->discName,discName) == 0) {
		printf("Entre aqui\n");
		inicioListaDiscos = inicioListaDiscos->sig;
		aux->sig = NULL;
		eliminarArchivoDisco(aux);
		numDiscos--;
		return aux;
	}
	else {
		Disco* scout = inicioListaDiscos;
		while(strcmp(scout->discName,discName) != 0) {
			scout = scout->sig;
			if(scout == NULL) {
				return NULL;
			}
		}
		while(aux->sig != scout) {
			aux = aux->sig;
		}
		aux->sig = scout->sig;
		scout->sig = NULL;
		eliminarArchivoDisco(scout);
		numDiscos--;
		return scout;
	}
}

void modificarDisco(char discName[]) {
	if(listaDiscosVacia()) {
		printf("No hay discos.\n");
	}
	else {
		int opcion;
		char buffer[24]={'\0'};
		Disco* scout = inicioListaDiscos;
		while( strcmp(scout->discName,discName) != 0 ) {
			scout = scout->sig;
			if (scout == NULL) {
				printf("Disco \"%s\" no encontrado.\n",discName);
				return;
			}
		}
		char backup[24];
		strcpy(backup,scout->discName);
		printf("Ingrese nuevos datos del disco:\n");
		printf("Artista: ");
		scanf(" %[^\n]",scout->artista);
		printf("Nombre del disco: ");
		scanf(" %[^\n]",scout->discName);
		do {
			printf("Precio: ");
			scanf("%s",buffer);
		} while (!validarFlotante(buffer));
		scout->precio = atof(buffer);
		do {
			printf("Año de lanzamiento: ");
			scanf("%s",buffer);
		} while (!validarEntero(buffer));
		scout->anio = atoi(buffer);
		renombrarArchivoDisco(backup,scout->discName);
		printf("Modificación finalizada.\n");
	}
}

void mostrarDiscos() {
	if(listaDiscosVacia()) {
		printf("No hay discos.\n");
	}
	else {
		Disco* aux = inicioListaDiscos;
		printf("\n Artista\t\t\tNombre del Disco\t\t\t Precio\t    Año\t       Comprados \n");
		while(aux != NULL) {
			imprimirDisco(aux);
			aux = aux->sig;
		}
	}
}

void imprimirDisco(Disco* disco) {
	printf("| ");
	imprimirDatoCadena(disco->artista);
	printf("| ");
	imprimirDatoCadena(disco->discName);
	printf("| ");
	imprimirDatoFlotante(disco->precio);
	printf("| ");
	imprimirDatoEntero(disco->anio);
	printf("| ");
	imprimirDatoEntero(disco->numCompras);
	printf("| ");
	printf("\n");
}

void copiarDisco(Disco* destino, Disco* origen) {
	strcpy(destino->discName,origen->discName);
	strcpy(destino->artista,origen->artista);
	destino->precio = origen->precio;
	destino->anio = origen->anio;
	destino->numCompras = origen->numCompras;
}

void ordenarDiscosNombre() {
	enum boolean listaOrdenada;
	Disco* aux = NULL;
	Disco* menorOrden = NULL;
	Disco* backup = (Disco*)malloc(sizeof(Disco));
	if (listaDiscosVacia()) {
		printf("No hay discos.\n");
	}
	else {
		do {
			listaOrdenada = true;
			aux = inicioListaDiscos;
			while (aux->sig != menorOrden) {
				if (strcmp(aux->discName,aux->sig->discName) > 0) { 
					copiarDisco(backup,aux);
					copiarDisco(aux,aux->sig);
					copiarDisco(aux->sig,backup);
					listaOrdenada = false;
				}
				aux = aux->sig;
			}
			menorOrden = aux;
		} while (listaOrdenada == false);
	}
	printf("Lista ordenada.\n");
}

void ordenarDiscosArtista() {
	enum boolean listaOrdenada;
	Disco* aux = NULL;
	Disco* menorOrden = NULL;
	Disco* backup = (Disco*)malloc(sizeof(Disco));
	if (listaDiscosVacia()) {
		printf("No hay discos.\n");
	}
	else {
		do {
			listaOrdenada = true;
			aux = inicioListaDiscos;
			while (aux->sig != menorOrden) {
				if (strcmp(aux->artista,aux->sig->artista) > 0) { 
					copiarDisco(backup,aux);
					copiarDisco(aux,aux->sig);
					copiarDisco(aux->sig,backup);
					listaOrdenada = false;
				}
				aux = aux->sig;
			}
			menorOrden = aux;
		} while (listaOrdenada == false);
	}
	printf("Lista ordenada.\n");
}

void ordenarDiscosPrecio() {
	enum boolean listaOrdenada;
	Disco* aux = NULL;
	Disco* menorOrden = NULL;
	Disco* backup = (Disco*)malloc(sizeof(Disco));
	if (listaDiscosVacia()) {
		printf("No hay discos.\n");
	}
	else {
		do {
			listaOrdenada = true;
			aux = inicioListaDiscos;
			while (aux->sig != menorOrden) {
				if (aux->precio > aux->sig->precio) { 
					copiarDisco(backup,aux);
					copiarDisco(aux,aux->sig);
					copiarDisco(aux->sig,backup);
					listaOrdenada = false;
				}
				aux = aux->sig;
			}
			menorOrden = aux;
		} while (listaOrdenada == false);
	}
	printf("Lista ordenada.\n");
}

void ordenarDiscosAnio() {
	enum boolean listaOrdenada;
	Disco* aux = NULL;
	Disco* menorOrden = NULL;
	Disco* backup = (Disco*)malloc(sizeof(Disco));
	if (listaDiscosVacia()) {
		printf("No hay discos.\n");
	}
	else {
		do {
			listaOrdenada = true;
			aux = inicioListaDiscos;
			while (aux->sig != menorOrden) {
				if (aux->anio > aux->sig->anio) { 
					copiarDisco(backup,aux);
					copiarDisco(aux,aux->sig);
					copiarDisco(aux->sig,backup);
					listaOrdenada = false;
				}
				aux = aux->sig;
			}
			menorOrden = aux;
		} while (listaOrdenada == false);
	}
	printf("Lista ordenada.\n");
}

void ordenarDiscosNumCompras() {
	enum boolean listaOrdenada;
	Disco* aux = NULL;
	Disco* menorOrden = NULL;
	Disco* backup = (Disco*)malloc(sizeof(Disco));
	if (listaDiscosVacia()) {
		printf("No hay discos.\n");
	}
	else {
		do {
			listaOrdenada = true;
			aux = inicioListaDiscos;
			while (aux->sig != menorOrden) {
				if (aux->numCompras > aux->sig->numCompras) { 
					copiarDisco(backup,aux);
					copiarDisco(aux,aux->sig);
					copiarDisco(aux->sig,backup);
					listaOrdenada = false;
				}
				aux = aux->sig;
			}
			menorOrden = aux;
		} while (listaOrdenada == false);
	}
	printf("Lista ordenada.\n");
}

void buscarDiscoNombre(char discName[]) {
	if(listaDiscosVacia()) {
		printf("No hay discos.\n");
	}
	else {
		Disco* aux = inicioListaDiscos;
		int contador = 0;
		printf("\n Artista\t\t\tNombre del Disco\t\t\t Precio\t    Año\t       Comprados \n");
		while(aux != NULL && strcmp(aux->discName,discName) != 0 ) {
			aux = aux->sig;
		}
		imprimirDisco(aux);
	}
}

void buscarDiscoArtista(char artista[]) {
	if(listaDiscosVacia()) {
		printf("No hay discos.\n");
	}
	else {
		Disco* aux = inicioListaDiscos;
		int contador = 0;
		printf("\n Artista\t\t\tNombre del Disco\t\t\t Precio\t    Año\t       Comprados \n");
		while(aux != NULL) {
			if (strcmp(aux->artista,artista) == 0) {
				imprimirDisco(aux);
				contador++;
			}
			aux = aux->sig;
		}
		printf("%d resultados encontrados.\n", contador);
	}
}

void buscarDiscoAnio(int anio) {
	if(listaDiscosVacia()) {
		printf("No hay discos.\n");
	}
	else {
		Disco* aux = inicioListaDiscos;
		int contador = 0;
		printf("\n Artista\t\tNombre del Disco\t\t\t Precio\t    Año\t       Comprados \n");
		while(aux != NULL) {
			if (aux->anio == anio) {
				imprimirDisco(aux);
				contador++;
			}
			aux = aux->sig;
		}
		printf("%d resultados encontrados.\n", contador);
	}
}

void buscarDiscoPrecioMenor(float precio) {
	if(listaDiscosVacia()) {
		printf("No hay discos.\n");
	}
	else {
		Disco* aux = inicioListaDiscos;
		int contador = 0;
		printf("\n Artista\t\tNombre del Disco\t\t\t Precio\t    Año\t       Comprados \n");
		while(aux != NULL) {
			if (aux->precio < precio) {
				imprimirDisco(aux);
				contador++;
			}
			aux = aux->sig;
		}
		printf("%d resultados encontrados.\n", contador);
	}
}

void buscarDiscoPrecioMayor(float precio) {
	if(listaDiscosVacia()) {
		printf("No hay discos.\n");
	}
	else {
		Disco* aux = inicioListaDiscos;
		int contador = 0;
		printf("\n Artista\t\tNombre del Disco\t Precio\t    Año\t       Comprados \n");
		while(aux != NULL) {
			if (aux->precio > precio) {
				imprimirDisco(aux);
				contador++;
			}
			aux = aux->sig;
		}
		printf("%d resultados encontrados.\n", contador);
	}
}

void buscarDiscoPrecioIgual(float precio) {
	if(listaDiscosVacia()) {
		printf("No hay discos.\n");
	}
	else {
		Disco* aux = inicioListaDiscos;
		int contador = 0;
		printf("\n Artista\t\tNombre del Disco\t Precio\t    Año\t       Comprados \n");
		while(aux != NULL) {
			if (aux->precio == precio) {
				imprimirDisco(aux);
				contador++;
			}
			aux = aux->sig;
		}
		printf("%d resultados encontrados.\n", contador);
	}
}

void cargarInventario() {
	DIR* directorio;
	struct dirent *ent;
	char nomCarpeta[40] =  "./discos/";
	directorio = opendir("./discos/");
	if (directorio == NULL) {
		printf("Error al cargar directorio.\n");
	}
	else {
		while ((ent = readdir(directorio)) !=  NULL) {
			strcpy(nomCarpeta,"./discos/");
			if ((strcmp(ent->d_name, ".") != 0) && (strcmp(ent->d_name, "..") != 0)) {
				strcat(nomCarpeta,ent->d_name);
				leerArchivoDisco(nomCarpeta);
			}
		}
		closedir(directorio);
	}
}

void leerArchivoDisco(char nomArch[]) {
	FILE* discArch = fopen(nomArch,"r");
	if (discArch == NULL) {
		printf("Error, no se encuentra el archivo\n");

	}
	else {	
		char discName[24];
		char artista[24];
		float precio;
		int anio;
		int numCompras;
		fscanf(discArch," %[^\n]\n",discName);
		fscanf(discArch," %[^\n]\n",artista);
		fscanf(discArch,"%f\n",&precio);
		fscanf(discArch,"%d\n",&anio);
		fscanf(discArch,"%d\n",&numCompras);
		agregarDisco(crearDisco(discName,artista,precio,anio,numCompras));
		fclose(discArch);
	}
}

void guardarDiscos() {
	char nomCarpeta[40];
	Disco* aux = inicioListaDiscos;
	while (aux != NULL) {
		strcpy(nomCarpeta,"./discos/");
		strcat(nomCarpeta,aux->discName);
		strcat(nomCarpeta,".txt");
		escribirArchivoDisco(nomCarpeta,aux);
		aux = aux->sig;
	}
}

void escribirArchivoDisco(char nomArch[],Disco* disco) {
	FILE* discArch = fopen(nomArch,"w");
	if (discArch == NULL) {
		printf("Error, no se encontró el archivo\n");
		return;
	}
	else {
		fprintf(discArch,"%s\n",disco->discName);
		fprintf(discArch,"%s\n",disco->artista);
		fprintf(discArch,"%.2f\n",disco->precio);
		fprintf(discArch,"%d\n",disco->anio);
		fprintf(discArch,"%d\n",disco->numCompras);
		fclose(discArch);
	}
}

void eliminarArchivoDisco(Disco* disco) {
	char nomArch[40] =  "./discos/";
	strcat(nomArch,disco->discName);
	strcat(nomArch,".txt");
	remove(nomArch);
}

void renombrarArchivoDisco(char oldName[],char newName[]) {
	char nomArch1[40] =  "./discos/";
	char nomArch2[40] =  "./discos/";
	strcat(nomArch1,oldName);
	strcat(nomArch2,newName);
	strcat(nomArch1,".txt");
	strcat(nomArch2,".txt");
	rename(nomArch1,nomArch2);
}