#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct userNode{
	char usuario[20];
	char pass[20];
	char usrArch[20];
	int edad;
	int numCompras;
	int discosComprados;
	struct userNode *sig;
} UserNode;

typedef struct discNode{
	char nombre[40];
	char artista[30];
	char discArch[30];
	int anio;
	double precio;
	int copiasVendidas;
	struct discNode *sig;
} DiscNode;

UserNode* leerListaUsuarios(UserNode *inicio);
UserNode* menuUsuario(UserNode *inicio);
void menuAdmin();
UserNode* listaIngresarUsuario(UserNode *inicio, char usrArchTmp[20], char usr[20], char pwd[20], int edadTmp, int numeroComprasTmp, int discosCompradosTmp);
DiscNode* mostrarCatalogo(DiscNode *inicio);
DiscNode* ingresarCatalogo(DiscNode *inicio,char discArchTmp[30],char nombreTmp[40],char artistaTmp[30],int anioTmp, double precioTmp, int copiasVendidasTmp);
int loggin(UserNode *users);
void guardarUsuario(UserNode *users);
UserNode* nuevoUsuario(UserNode *inicio);

int main(int argc, char const *argv[]){
	UserNode *users = NULL;
	users = leerListaUsuarios(users);

	loggin(users);

	guardarUsuario(users);
	return 0;
}

int loggin(UserNode *users){
	UserNode *inicio = users;

	char usr[20];
	char pwd[20];
	int i=0;
	int opcion;

	do{
		system("clear");
		printf("\n\tBienvenido! n.n/");
		printf("\n\n1.- Iniciar sesion");
		printf("\n2.- Crear usuario");
		printf("\n3.- Salir\n");
		printf("\nIngresa la opcion que deseas realizar: ");
		scanf("%d",&opcion);
		getchar();

		switch(opcion){
			case 1:

				do{
				fflush(stdin);
				printf("Ingresa tu nombre de usuario: ");
				scanf("%s", usr);
				printf("Ingresa la contraseña: ");
				scanf("%s", pwd);

				if(strcmp(usr,"admin")==0 && strcmp(pwd,"admin")==0){
					printf("\nIngreso al sistema como administrador");
					//menuAdmin();
					return 1;	
				}else{
					while(inicio != NULL){
						printf("%s, %s, %s, %s\n",usr,inicio->usuario,pwd,inicio->pass);
						if(strcmp(usr,inicio->usuario)==0 && strcmp(pwd,inicio->pass)==0){
							printf("\nIngreso al sistema como usuario");
							return 1;
						}
						inicio=inicio->sig;
					}
					
				}

					printf("\n\n\tUsuario o contraseña incorrectos!");
					getchar();
					getchar();
					i++;
				}while(i<3);
				return 0;

				break;

			case 2:
				users = nuevoUsuario(users);
				break;

			case 3:
				printf("\nHasta pronto n.n/\n");
				break;

			default:
				printf("\n\tOpcion no válida >:v \n");

		}
	}while(opcion!=3);

	return 0;
}

UserNode* leerListaUsuarios(UserNode *inicio){
	FILE *ap = fopen("usuarios.txt","r");
	FILE *ap2;
	char usrArch[20];
	char usuario[20];
	char pass[20];
	int edad, numCompras, discosComprados;

	if(!ap){
		printf("Error en la apartura del archivo :(\n");
		return inicio;
	}
	while(!feof(ap)){
		fscanf(ap,"%s",usrArch);
		ap2 = fopen(usrArch,"r");
		fscanf(ap2,"%s %s %d %d %d\n", usuario, pass, &edad, &numCompras, &discosComprados);
		inicio = listaIngresarUsuario(inicio, usrArch, usuario, pass, edad, numCompras, discosComprados);
	}

	return inicio;
}

UserNode* listaIngresarUsuario(UserNode *inicio, char usrArchTmp[20], char usr[20], char pwd[20], int edadTmp, int numComprasTmp, int discosCompradosTmp){

	UserNode *nodoActual = inicio;

	if(inicio==NULL){
		nodoActual = malloc(sizeof(UserNode));
		strcpy(nodoActual->usrArch,usrArchTmp);
		strcpy(nodoActual->usuario,usr);
		strcpy(nodoActual->pass,pwd);
		nodoActual->edad = edadTmp;
		nodoActual->numCompras = numComprasTmp;
		nodoActual->discosComprados = discosCompradosTmp;
		nodoActual->sig = NULL;
		inicio = nodoActual;
	}else{
		while(nodoActual->sig != NULL){
			nodoActual = nodoActual->sig;
		UserNode *nuevoNodo;
	}
	UserNode *nuevoNodo = malloc(sizeof(UserNode));
	strcpy(nuevoNodo->usrArch,usrArchTmp);
	strcpy(nuevoNodo->usuario,usr);
	strcpy(nuevoNodo->pass,pwd);
	nuevoNodo->edad = edadTmp;
	nuevoNodo->numCompras = numComprasTmp;
	nuevoNodo->discosComprados = discosCompradosTmp;
	nuevoNodo->sig = NULL;
	nodoActual->sig = nuevoNodo;

	}
	return inicio;
}

UserNode* nuevoUsuario(UserNode *users){
	UserNode *nuevoNodo = users;
	UserNode *nodoActual = users;
	char usr[20],pwd[20];
	int edad;

	printf("\t\nCreación de usuarios");
	printf("\n\nIngresa nuevo usuario: ");
	scanf("%s", usr);
	printf("\nIngresa nueva contraseña: ");
	scanf("%s", pwd);
	printf("\nIngresa tu edad: ");
	scanf("%d",&edad);

	while(nodoActual->sig != NULL){
		if(strcmp(nodoActual->usuario,usr)==0){
			printf("\nUsuario ya existe\n");
			return users;
		}else{
			nodoActual = nodoActual->sig;
		}
	}

	nuevoNodo = malloc(sizeof(UserNode));
	strcpy(nuevoNodo->usrArch,usr);
	strcpy(nuevoNodo->usuario,usr);
	strcpy(nuevoNodo->pass,pwd);
	nuevoNodo->edad = edad;
	nuevoNodo->numCompras = 0;
	nuevoNodo->discosComprados = 0;
	nuevoNodo->sig = NULL;
	nodoActual->sig = nuevoNodo;

	return users;
}

void guardarUsuario(UserNode *users){
	FILE *ap = fopen("usuarios.txt","w");
	FILE *ap2 = NULL;
	UserNode *nodoActual = users;
	UserNode *tmp = NULL;

	while(nodoActual != NULL){
		fprintf(ap, "%s\n", nodoActual->usrArch);
		ap2 = fopen(nodoActual->usrArch,"w");
		fprintf(ap2, "%s %s %d %d %d\n", nodoActual->usuario, nodoActual->pass, nodoActual->edad, nodoActual->numCompras, nodoActual->discosComprados);
		tmp = nodoActual->sig;
		free(nodoActual);
		nodoActual = tmp;
	}
}

UserNode* menuUsuario(UserNode *inicio){

	int opcion;

	do{
		system("clear");
		printf("\n\tMenú Usuario\n");
		printf("\n¿Que deseas hacer?\n");
		printf("\n1.- Ver catálogo de discos existentes");
		printf("\n2.- Realizar una búsqueda específica");
		printf("\n3.- Comprar un disco");
		printf("\n4.- Mostrar y editar información del perfil");
		printf("\n5.- Salir");
		printf("\n\nIngresa la opción deseada: ");
		scanf("%d", &opcion);
		getchar();

		switch(opcion){
			
			case 1:
				printf("\t\nCatálogo de discos");
				//mostrarCatalogo();
				break;
			case 2:
				printf("\t\nBúsquedas");
				break;
			case 3:
				printf("\t\nComprar");
				break;
			case 4:
				printf("\t\nMostrar y/o editar información");
				break;
			case 5:
				printf("\t\nHasta luego n.n/");
				break;
			default:
				printf("\t\nERROR! Opción no válida");

		}
 	
	}while(opcion!=5);

	return inicio;
}

DiscNode* mostrarCatalogo(DiscNode *inicio){
	FILE *ap = fopen("discos.txt","r");
	FILE *ap2;
	char nombre[40];
	char artista[30];
	char discArch[30];
	int anio;
	double precio;
	int copiasVendidas;

	if(!ap){
		printf("Error en la apertura del archivo");
		return inicio;
	}
	do{
		fscanf(ap,"%s",discArch);
		ap2 = fopen(discArch,"r");
		fscanf(ap2,"%s %s %d %d",nombre, artista,&anio,&copiasVendidas);
		inicio = ingresarCatalogo(inicio, discArch, nombre, artista, anio, precio, copiasVendidas);
	}while(!feof(ap));

	return inicio;
}

DiscNode* ingresarCatalogo(DiscNode *inicio,char discArchTmp[30],char nombreTmp[40],char artistaTmp[30],int anioTmp, double precioTmp, int copiasVendidasTmp){
	DiscNode *nodoActual = inicio;
	if(inicio==NULL){
		nodoActual = malloc(sizeof(DiscNode));
		strcpy(nodoActual->discArch,discArchTmp);
		strcpy(nodoActual->nombre,nombreTmp);
		strcpy(nodoActual->artista,artistaTmp);
		nodoActual->precio = precioTmp;
		nodoActual->anio = anioTmp;
		nodoActual->copiasVendidas = copiasVendidasTmp;
		nodoActual->sig = NULL;

		inicio = nodoActual;

	}
	else{
		while(nodoActual->sig != NULL){
			nodoActual = nodoActual->sig;
		}
		DiscNode *nuevoNodo = malloc(sizeof(DiscNode));
		strcpy(nuevoNodo->discArch,discArchTmp);
		strcpy(nuevoNodo->nombre,nombreTmp);
		strcpy(nuevoNodo->artista,artistaTmp);
		nuevoNodo->precio = precioTmp;
		nuevoNodo->anio = anioTmp;
		nuevoNodo->copiasVendidas = copiasVendidasTmp;
		nuevoNodo->sig = NULL;
		nodoActual->sig = nuevoNodo;

	}
	return inicio;
}

void menuAdmin(){
	int opcion;

	do{
		system("clear");
		printf("\n\tMenú Administrador\n");
		printf("\n¿Que deseas hacer?\n");
		printf("\n1.- Ver catálogo de discos existentes");
		printf("\n2.- Editar información de disco");
		printf("\n3.- Agregar un disco");
		printf("\n4.- Borrar un disco");
		printf("\n5.- Realizar un ordenamiento");
		printf("\n6.- Realizar búsquedas");
		printf("\n7.- Agregar un usuario");
		printf("\n8.- Borrar un usuario");
		printf("\n9.- Salir");
		printf("\n\nIngresa la opción deseada: ");
		scanf("%d", &opcion);
		getchar();

		switch(opcion){
			
			case 1:
				printf("\t\nCatálogo de discos");
				//mostrarCatalogo();
				break;
			case 2:
				printf("\t\nEditar informacion de disco");
				break;
			case 3:
				printf("\t\nAgregar un disco");
				break;
			case 4:
				printf("\t\nBorrar un disco");
				break;
			case 5:
				printf("\t\nRealizar un ordenamiento");
				break;
			case 6:
				printf("\t\nRealizar búsquedas");
				break;
			case 7:
				printf("\t\nAgregar un usuario");
				break;
			case 8:
				printf("\t\nBorrar un usuario");
				break;
			case 9:
				printf("\t\nHasta luego n.n/");
				break;
			default:
				printf("\t\nERROR! Opción no válida");

		}
 	
	}while(opcion!=9);

}