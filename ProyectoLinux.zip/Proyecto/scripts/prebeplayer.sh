#!/bin/bash


PATH+=

salir='N'
nivellista=0

function cambiadir(){
	cd "$1"
}

function listadir() {
	for file in "$PWD"/*; do
		if [[ -d "$file" ]]; then
			nombre=`echo -e "$file" | grep -E -o "[][a-zA-Z0-9_─–\.\+\(\)\ \'\!\-]*$"`
			echo -e " ── $nombre\E[0m"
		elif [[ `echo -e "$file" | grep -E -o "[][a-zA-Z0-9_─–\.\+\(\)\ \'\!\-]+.mp3"` ]]; then
			nombre=`echo -e "$file" | grep -E -o "[][a-zA-Z0-9_─–\.\+\(\)\ \'\!\-]+.mp3"`
			echo -e " ── $nombre\E[0m"
			let cnt=cnt+1
		fi
	done
	if [[ cnt -eq 0 ]]; then
			echo -e "\nNo se encontraron canciones en este directorio :("
	fi
}

function muestra_controles(){
	echo -e "Reproduciendo carpeta"
	echo -e "Controles:"
	echo -e "[espacio] pausa		[f] pista siguiente		[d] pista anterior"
	echo -e "[b] reiniciar canción	[q] detener			[+] subir volumen"
	echo -e "[.] adelantar		[,] rebobinar			[-] bajar volumen"
	echo -e "[t] información sobre la canción			[h] más comandos"
	echo -e "[l] mostrar lista de reproduccion actual"
}

while [[ $salir != "S" ]]; do 	
	if [[ -f /usr/bin/mpg123 ]]; then

		cambiadir "./musica"
		echo `clear`
		echo -e "PREBEPLAYER"
		echo -e "Menú: "
		echo -e "1. Lista canciones y subdirectorios en la carpeta actual"
		echo -e "2. Reproducir carpeta actual en orden secuencial"
		echo -e "3. Reproducir carpeta actual en orden aleatorio"
		echo -e "4. Cambiar de directorio"
		echo -e "5. Ayuda"
		echo -e "6. Salir"
		echo -e "Directorio actual: $PWD"
		echo -en "¿Qué desea realizar? Ingrese una opción: "
		read opcion
		case $opcion in
			1) 
				echo -e "\nLista de canciones y subdirectorios"
				cnt=0
				listadir
				echo -e -n "\nPulse Enter para continuar."
				read
				;;
			2)
				muestra_controles
				mpg123 -qC *
				;;
			3)
				muestra_controles
				mpg123 -qzC *
				;;
			4)	
				echo -en "\nIngresa el directorio: "
				read  directorio_nuevo
				cambiadir $directorio_nuevo
				echo -e -n "\nPulse Enter para continuar."
				;;
			5)	
				echo -e "aiua"
				echo -e -n "\nPulse Enter para continuar."
				read
				;;
			6)	
				salir='S';;
			*)
				echo -e -n "\nOpción inválida. Pulse Enter para continuar."
				read
				;;
		esac
	else
		echo -e "El paquete mpg123 no está instalado."
		echo -e -n "Pulse Enter para iniciar la instalación"
		read
		sudo apt-get install mpg123
		echo -e -n "Instalación terminada. Pulse Enter para continuar."
		read
	fi
done
