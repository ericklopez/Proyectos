#!/bin/bash

function valida_usuario() {
	cadena_magica=$(sudo grep "^$1:" /etc/shadow | cut -d ':' -f 2)
	sudo grep -q "^$1:$(mkpasswd -H SHA-512 -S ${cadena_magica:3:8} $2)" /etc/shadow
	if [[ $? -eq 0 ]]; then
		usuario_valido=1
	else
		usuario_valido=0
	fi
}

trap '' INT TSTP
sudo -v
echo -e "Bienvenido a la prebeshell."
echo -e -n "\n\tUsuario: "
read usuario
echo -e -n "\n\tContraseña: "
read -s contrasena
valida_usuario $usuario $contrasena
if [[ $usuario_valido -eq 1 ]]; then

	origen=`echo "$PWD/scripts"`
	echo -e "\n\n\t\t\tBienvenido $usuario\n"
	while :; do
		trap '' 2
		trap '' SIGTSTP
		prompt="$USER in $PWD: "
		trap '' 2
		trap '' SIGTSTP
		read -p "$prompt" comando
		read -r arg0 arg1 arg2 <<< "$comando"
		case $arg0 in
			ahorcado )		#Completo
				$origen/ahorcado.sh $origen;;
			arbol )			#Completo
				$origen/arbol.sh;;
			infosis )		#Completo
				$origen/infosis.sh;;
			ayuda )
				$origen/ayuda.sh;;
			fecha )			#Funcional
				$origen/fecha.sh;;
			hora )			#Funcional
				$origen/hora.sh;;
			busca )		#Funcional
				$origen/busqueda.sh $arg1 $arg2;;
			prebeplayer )	#Funcional
				$origen/prebeplayer.sh;;
			creditos )
				$origen/creditos.sh;;
			salir )		
				exit 0;;
			* )
				eval "$comando"
				;;
		esac
	done

else
	echo -e "\n\n\t ¡Usuario/contraseña inválido(s)!"
	exit 1
fi

# This example script, and much of the above explanation supplied by
# Stéphane Chazelas (thanks again).